import java.util.*;
public class Main
{
	public static void main(String[] args) {
		List<Integer>list1= Arrays.asList(1, 2,2,3, 4, 5);
		List<Integer>list2= new ArrayList<>();
		list2.add(list1.get(0));
		for (int i=1;i<list1.size() ;i++ ) {
		    if(list1.get(i)!=list1.get(i-1)){
		        list2.add(list1.get(i));
		    }
		    
		}
		System.out.println(list2);
	}
}
