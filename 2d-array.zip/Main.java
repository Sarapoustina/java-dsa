import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[][] arr1 = {
            {1, 2, 3},
            {4, 5, 6}
        };
        int[][] arr2 = {
            {7, 8, 9},
            {10, 11, 12}
        };

        int[][] sumArray = new int[2][3];

        for (int i = 0; i < 2; i++) {       
            for (int j = 0; j < 3; j++) {    
                sumArray[i][j] = arr1[i][j] + arr2[i][j];
            }
        }
        System.out.println("Sum of two arrays:");
        for (int[] row : sumArray) {
            System.out.println(Arrays.toString(row));
        }
        
        int sum=0;
        for(int k=0;k<sumArray.length;k++){
            for(int m=0;m<sumArray[k].length;m++){
                sum +=sumArray[k][m];
            }
        }
        System.out.println(sum);
    }
}





