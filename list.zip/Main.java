import java.util.*;
public class Main
{
	public static void main(String[] args) {
		List<Integer> list1= new ArrayList<>();
		for(int i=1;i<11;i++){
		    list1.add(i);
		    System.out.println(i);
		}
		System.out.println(list1);
	
	   int target=5;
	   int z=0;
	
	   for(int j=0;j<list1.size();j++){
	    if(list1.get(j)==target){
	        z= j;
	        System.out.println(z);
	    }
	}
	int sum=0;
	int product=1;
	for(int k=0;k<list1.size();k++){
	    sum+= list1.get(k);
	    product *=list1.get(k);
	}
	System.out.println("sum is"+sum);
	System.out.println("product is "+product);
	}
}
